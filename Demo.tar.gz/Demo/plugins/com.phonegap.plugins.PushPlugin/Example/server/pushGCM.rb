require 'rubygems'
require 'pushmeup'
GCM.host = 'https://android.googleapis.com/gcm/send'
GCM.format = :json
GCM.key = "AIzaSyA_-wCKgPAocSHd_mZTtneEghIDpGPFCRY"
destination = ["APA91bH1M32iQ1RMbp5RyyquOleutSv9_BQKEuQAOI8pAHdFpMvxX_CvcDZC4RuhRaSSlfvS1Vkt1LvuF8Ta-27KL5gH_oY0ikwh4FGBRumgUwydjO3cF4qFz6cQ_cuEv7UY4BRcu4s_"]
data = {:message => "PhoneGap Build rocks!", :msgcnt => "1", :soundname => "beep.wav"}

GCM.send_notification( destination, data)
